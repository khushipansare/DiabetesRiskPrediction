from flask import Flask, request, jsonify
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
import joblib

# Initialize Flask app
app = Flask(__name__)

# Load dataset and preprocess
file_path = 'diabetes.csv'  # Ensure the CSV file is in the same directory
data = pd.read_csv(file_path)
X = data.drop('Outcome', axis=1)  # Features
y = data['Outcome']  # Target

# Standardize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train models
decision_tree_model = DecisionTreeClassifier()
decision_tree_model.fit(X_scaled, y)

svm_model = SVC(probability=True)
svm_model.fit(X_scaled, y)

# Save models and scaler
joblib.dump(decision_tree_model, 'decision_tree_model.pkl')
joblib.dump(svm_model, 'svm_model.pkl')
joblib.dump(scaler, 'scaler.pkl')

# Load models and scaler
scaler = joblib.load('scaler.pkl')
decision_tree_model = joblib.load('decision_tree_model.pkl')
svm_model = joblib.load('svm_model.pkl')

@app.route('/')
def home():
    # Sample data for demonstration
    sample_data = {
        "Pregnancies": 2,
        "Glucose": 120,
        "BloodPressure": 70,
        "SkinThickness": 20,
        "Insulin": 85,
        "BMI": 25.5,
        "DiabetesPedigreeFunction": 0.627,
        "Age": 30
    }
    input_df = pd.DataFrame([sample_data])
    input_scaled = scaler.transform(input_df)
    dt_prediction = decision_tree_model.predict(input_scaled)[0]
    svm_prediction = svm_model.predict(input_scaled)[0]

    return jsonify({
        "message": "Welcome to the Diabetes Prediction API",
        "status": "Running",
        "sample_data": sample_data,
        "decision_tree_prediction": int(dt_prediction),
        "svm_prediction": int(svm_prediction)
    })

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Parse input JSON
        input_data = request.get_json()
        
        # Extract feature names and values
        feature_names = ['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 
                         'Insulin', 'BMI', 'DiabetesPedigreeFunction', 'Age']
        input_df = pd.DataFrame([input_data], columns=feature_names)

        # Scale the input data
        input_scaled = scaler.transform(input_df)

        # Make predictions
        decision_tree_prediction = decision_tree_model.predict(input_scaled)[0]
        svm_prediction = svm_model.predict(input_scaled)[0]

        # Return predictions as JSON
        return jsonify({
            "decision_tree_prediction": int(decision_tree_prediction),
            "svm_prediction": int(svm_prediction)
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)
