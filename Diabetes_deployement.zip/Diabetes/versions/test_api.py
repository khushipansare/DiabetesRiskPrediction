import requests

# Define the API URL
url = "http://127.0.0.1:5000/predict"

# Define sample input data
sample_data = {
    "Pregnancies": 2,
    "Glucose": 120,
    "BloodPressure": 70,
    "SkinThickness": 20,
    "Insulin": 85,
    "BMI": 25.5,
    "DiabetesPedigreeFunction": 0.627,
    "Age": 30
}

# Send POST request
response = requests.post(url, json=sample_data)

# Print the response
print("Response:", response.json())
