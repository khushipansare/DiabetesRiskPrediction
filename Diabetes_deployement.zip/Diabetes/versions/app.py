import joblib
from flask import Flask, request, jsonify

app = Flask(__name__)

# Load models and scaler
try:
    dt_model = joblib.load('C:\\Users\\Khush Agrawal\\Downloads\\Diabetes\\models\\diabetes_decision_tree.pkl')
    svm_model = joblib.load('C:\\Users\\Khush Agrawal\\Downloads\\Diabetes\\models\\diabetes_svm.pkl')
    scaler = joblib.load('C:\\Users\\Khush Agrawal\\Downloads\\Diabetes\\models\\scaler.pkl')
    print("Models and scaler loaded successfully!")
except FileNotFoundError as e:
    print("File not found:", e)
except Exception as e:
    print("Error loading models or scaler:", e)


@app.route('/')
def home():
    return jsonify({"message": "Welcome to the Diabetes Prediction API", "status": "Running"})


@app.route('/predict', methods=['POST'])
def predict():
    if not dt_model or not svm_model or not scaler:
        return jsonify({"error": "Models or scaler not loaded. Check the server logs for details."})

    data = request.get_json()
    try:
        # Extract input features and scale them
        input_data = [
            data.get("Pregnancies"),
            data.get("Glucose"),
            data.get("BloodPressure"),
            data.get("SkinThickness"),
            data.get("Insulin"),
            data.get("BMI"),
            data.get("DiabetesPedigreeFunction"),
            data.get("Age"),
        ]
        scaled_data = scaler.transform([input_data])

        # Predictions
        dt_prediction = dt_model.predict(scaled_data)[0]
        svm_prediction = svm_model.predict(scaled_data)[0]

        return jsonify({
            "decision_tree_prediction": int(dt_prediction),
            "svm_prediction": int(svm_prediction)
        })
    except Exception as e:
        return jsonify({"error": str(e)})


if __name__ == "__main__":
    app.run(debug=True)
