
## Diabetes Prediction API
This project provides an API for predicting diabetes outcomes using two machine learning models: a Decision Tree and a Support Vector Machine (SVM). The API is built using Flask and allows for predictions based on user-provided input data.

# Libraries
Ensure the following Python libraries are installed:

Flask

pandas

numpy

scikit-learn

joblib

# Install them using the following command:

pip install Flask pandas numpy scikit-learn joblib
Dataset
The API uses the diabetes.csv dataset. Ensure the dataset is available in the same directory as the script.

# The dataset should include the following columns:

Pregnancies

Glucose

BloodPressure

SkinThickness

Insulin

BMI

DiabetesPedigreeFunction

Age

Outcome

## Ensure Python is Installed: Confirm Python 3.7+ is installed on your system by running:

python --version
## Install Dependencies: Use the following command to install the required libraries:
pip install -r requirements.txt

(If requirements.txt is not available, manually install the libraries listed above.)

## Place the Dataset: Ensure the diabetes.csv file is in the same directory as the script.

## Run the Script: Start the Flask application by executing:
python final.py
Access the API: Open your browser or use tools like Postman to navigate.

## Testing the API
Using Postman

Home Endpoint Test: Send a GET request to:

http://127.0.0.1:5000/
Prediction Test:

Set the method to POST.

Use the URL:

http://127.0.0.1:5000/predict
In the Body section, select "raw" and choose JSON format.

Provide input data in JSON format (as shown above).

Using cURL
Run the following command to test the /predict endpoint:

curl -X POST -H "Content-Type: application/json" -d '{"Pregnancies": 5, "Glucose": 150, "BloodPressure": 80, "SkinThickness": 30, "Insulin": 100, "BMI": 28.5, "DiabetesPedigreeFunction": 0.5, "Age": 35}' http://127.0.0.1:5000/predict



### 1. **Importing Libraries**
   - `Flask` is used to create the web application.
   - `request` and `jsonify` are used for handling incoming API requests and responses.
   - `numpy` and `pandas` are used for data manipulation and handling.
   - `StandardScaler` from `sklearn.preprocessing` is used for feature scaling.
   - `DecisionTreeClassifier` and `SVC` from `sklearn` are machine learning models for classification.
   - `joblib` is used to save and load models and scaler.

### 2. **Initialize Flask App**
   - `app = Flask(__name__)`: This initializes the Flask app, allowing you to create and handle web routes.

### 3. **Loading and Preprocessing the Dataset**
   - `file_path = 'diabetes.csv'`: The path to the dataset (assumed to be in the same directory).
   - `data = pd.read_csv(file_path)`: Reads the CSV file into a DataFrame.
   - `X = data.drop('Outcome', axis=1)`: Splits the features from the target variable (`Outcome`).
   - `y = data['Outcome']`: The target variable is `Outcome`, which is used for prediction.
   - `scaler = StandardScaler()`: Initializes a `StandardScaler` object to scale the features.
   - `X_scaled = scaler.fit_transform(X)`: Scales the feature data (`X`) for consistency in model training.

### 4. **Training Machine Learning Models**
   - `decision_tree_model = DecisionTreeClassifier()`: Initializes a decision tree classifier.
   - `decision_tree_model.fit(X_scaled, y)`: Trains the decision tree model using the scaled data and target variable.
   - `svm_model = SVC(probability=True)`: Initializes a support vector machine (SVM) model, enabling probabilistic predictions.
   - `svm_model.fit(X_scaled, y)`: Trains the SVM model using the scaled data and target variable.

### 5. **Saving the Trained Models and Scaler**
   - `joblib.dump(decision_tree_model, 'decision_tree_model.pkl')`: Saves the trained decision tree model to a file.
   - `joblib.dump(svm_model, 'svm_model.pkl')`: Saves the trained SVM model to a file.
   - `joblib.dump(scaler, 'scaler.pkl')`: Saves the scaler to a file for later use in scaling input data during predictions.

### 6. **Loading Saved Models and Scaler**
   - The models and scaler are loaded back from the saved `.pkl` files:
     - `scaler = joblib.load('scaler.pkl')`
     - `decision_tree_model = joblib.load('decision_tree_model.pkl')`
     - `svm_model = joblib.load('svm_model.pkl')`

### 7. **Defining Flask Routes**
   - **`@app.route('/')` (Home Route)**:
     - This route returns a welcome message with some sample input data and predictions from both models (Decision Tree and SVM).
     - The sample data is provided as a dictionary, which is then converted to a DataFrame and scaled using the preloaded scaler.
     - The predictions from both models (`decision_tree_model.predict` and `svm_model.predict`) are returned as JSON.

   - **`@app.route('/predict', methods=['POST'])` (Prediction Route)**:
     - This route accepts POST requests with input data in JSON format.
     - The input data is expected to contain feature values corresponding to the features in the dataset.
     - The input data is converted into a DataFrame and scaled.
     - Predictions are made using both the Decision Tree and SVM models.
     - The predictions are returned as a JSON response.

     **Error Handling**:
     - If an error occurs during prediction (e.g., invalid input), an error message is returned in the response with a 400 status code.

### 8. **Starting the Flask Server**
   - `app.run(debug=True)`: Starts the Flask app in debug mode, allowing for easier debugging and automatic reloading during development.

### 9. **API Behavior**
   - **Home Route (`/`)**:
     - When accessed, this route provides a message about the status of the API, along with sample input data and model predictions for that sample.
   - **Predict Route (`/predict`)**:
     - This route allows users to send input data (features of a patient) via a POST request to predict whether they have diabetes (binary classification).
     - The response contains predictions from both models (Decision Tree and SVM).

### Example Request (for `/predict`):
```json
{
  "Pregnancies": 2,
  "Glucose": 120,
  "BloodPressure": 70,
  "SkinThickness": 20,
  "Insulin": 85,
  "BMI": 25.5,
  "DiabetesPedigreeFunction": 0.627,
  "Age": 30
}
```

### Example Response:
```json
{
  "decision_tree_prediction": 1,
  "svm_prediction": 1
}
```

This response means that both models (Decision Tree and SVM) predict that the individual has diabetes (`1`).

### Conclusion:
This code demonstrates how to create a simple Flask API for predicting diabetes using machine learning models (Decision Tree and SVM), handling both training and prediction processes. The trained models are saved and loaded for use in predicting new input data provided by users.